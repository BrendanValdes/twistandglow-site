import * as React from 'react'
import { render } from '@react-email/components'
import { createFileRoute } from '@tanstack/react-router'
import { z } from 'zod'
import { TEMPLATES } from '@/lib/email-templates/registry'

const SITE_NAME = 'vegas-glow-showcase'
const SENDER_DOMAIN = 'notify.twistandglowlv.com'
const FROM_DOMAIN = 'twistandglowlv.com'
const TEMPLATE_NAME = 'quote-request'

const Schema = z.object({
  name: z.string().max(200).optional().default(''),
  email: z.string().max(200).optional().default(''),
  phone: z.string().max(80).optional().default(''),
  contact: z.string().max(200).optional().default(''),
  eventDate: z.string().max(80).optional().default(''),
  startTime: z.string().max(40).optional().default(''),
  duration: z.string().max(40).optional().default(''),
  location: z.string().max(300).optional().default(''),
  eventType: z.string().max(120).optional().default(''),
  guests: z.string().max(40).optional().default(''),
  details: z.string().max(5000).optional().default(''),
  services: z.string().max(500).optional().default(''),
  source: z.string().max(80).optional().default(''),
})

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
}

function generateToken(): string {
  const bytes = new Uint8Array(32)
  crypto.getRandomValues(bytes)
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, '0')).join('')
}

export const Route = createFileRoute('/api/public/quote-request')({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders }),
      POST: async ({ request }) => {
        let raw: unknown
        try {
          raw = await request.json()
        } catch {
          return Response.json({ error: 'Invalid JSON' }, { status: 400, headers: corsHeaders })
        }
        const parsed = Schema.safeParse(raw)
        if (!parsed.success) {
          return Response.json({ error: 'Invalid input' }, { status: 400, headers: corsHeaders })
        }
        const data = parsed.data

        const entry = TEMPLATES[TEMPLATE_NAME]
        if (!entry || !entry.to) {
          return Response.json({ error: 'Template not configured' }, { status: 500, headers: corsHeaders })
        }

        const submittedAt = new Date().toISOString()
        const templateData = { ...data, submittedAt }

        const html = await render(React.createElement(entry.component, templateData))
        const text = await render(React.createElement(entry.component, templateData), { plainText: true })
        const subject = typeof entry.subject === 'function' ? entry.subject(templateData) : entry.subject
        const recipient = entry.to
        const messageId = crypto.randomUUID()

        const { supabaseAdmin } = await import('@/integrations/supabase/client.server')

        // Unsubscribe token (one per email) — required by queue payload shape
        let unsubscribeToken = generateToken()
        const { data: existing } = await supabaseAdmin
          .from('email_unsubscribe_tokens')
          .select('token, used_at')
          .eq('email', recipient.toLowerCase())
          .maybeSingle()
        if (existing && !existing.used_at) {
          unsubscribeToken = existing.token
        } else if (!existing) {
          await supabaseAdmin
            .from('email_unsubscribe_tokens')
            .upsert({ token: unsubscribeToken, email: recipient.toLowerCase() }, { onConflict: 'email', ignoreDuplicates: true })
          const { data: stored } = await supabaseAdmin
            .from('email_unsubscribe_tokens')
            .select('token')
            .eq('email', recipient.toLowerCase())
            .maybeSingle()
          if (stored) unsubscribeToken = stored.token
        }

        await supabaseAdmin.from('email_send_log').insert({
          message_id: messageId,
          template_name: TEMPLATE_NAME,
          recipient_email: recipient,
          status: 'pending',
        })

        const { error: enqueueError } = await supabaseAdmin.rpc('enqueue_email', {
          queue_name: 'transactional_emails',
          payload: {
            message_id: messageId,
            to: recipient,
            from: `${SITE_NAME} <noreply@${FROM_DOMAIN}>`,
            sender_domain: SENDER_DOMAIN,
            subject,
            html,
            text,
            purpose: 'transactional',
            label: TEMPLATE_NAME,
            idempotency_key: messageId,
            unsubscribe_token: unsubscribeToken,
            queued_at: submittedAt,
          },
        })

        if (enqueueError) {
          await supabaseAdmin.from('email_send_log').insert({
            message_id: messageId,
            template_name: TEMPLATE_NAME,
            recipient_email: recipient,
            status: 'failed',
            error_message: 'Failed to enqueue email',
          })
          return Response.json({ error: 'Failed to enqueue email' }, { status: 500, headers: corsHeaders })
        }

        return Response.json({ success: true }, { headers: corsHeaders })
      },
    },
  },
})